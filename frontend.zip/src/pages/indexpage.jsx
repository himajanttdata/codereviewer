import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../App.css';
import axios from 'axios';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome } from '@fortawesome/free-solid-svg-icons';
import { faMoon, faSun } from '@fortawesome/free-solid-svg-icons';
import { faGithub } from '@fortawesome/free-brands-svg-icons';

const IndexPage = () => {
  const [githubURL, setGithubURL] = useState('');
  const [loading, setLoading] = useState(false);
  const [files, setFiles] = useState([]);
  const [repoFiles, setRepoFiles] = useState([]);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [darkMode, setDarkMode] = useState(false);
  const navigate = useNavigate();

  const handleAnalyze = async () => {
    if (!githubURL && files.length === 0 && selectedFiles.length === 0) {
      alert("Please provide a GitHub URL, upload files, or select repo files.");
      return;
    }
    setLoading(true);

    const formData = new FormData();

    if (githubURL) {
      formData.append("repo_url", githubURL);
    }

    if (files.length > 0) {
      for (let i = 0; i < files.length; i++) {
        formData.append("file", files[i]);
      }
    }

    try {
      if (selectedFiles.length > 0) {
        // Send selected GitHub files for analysis
        const response = await axios.post("http://127.0.0.1:5000/analyze_selected", {
          file_urls: selectedFiles,
        });

        if (response.data.success) {
          navigate("/review");
        } else {
          throw new Error(response.data.error || "Analysis failed.");
        }
      } else {
        const response = await axios.post("http://127.0.0.1:5000/submit", formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
        });

        if (response.data.success) {
          sessionStorage.setItem("githubURL", githubURL);
          sessionStorage.setItem("uploadedFiles", JSON.stringify([...files].map(f => f.name)));
          navigate("/review");
        } else {
          throw new Error(response.data.error || "Failed to analyze code.");
        }
      }
    } catch (err) {
      alert("Error: " + err.message);
      console.error("Analysis Error:", err);
    }
  };

  const fetchRepoFiles = async () => {
    const cleanURL = githubURL.trim().replace(/\.git$/, '');
    const match = cleanURL.match(/^https:\/\/github\.com\/([^\/]+)\/([^\/]+)$/);

    if (!match) {
      alert("Invalid GitHub repository URL.");
      return;
    }

    const [_, owner, repo] = match;
    const apiURL = `https://api.github.com/repos/${owner}/${repo}/contents`;

    try {
      const response = await fetch(apiURL);
      if (!response.ok) throw new Error("GitHub API failed");

      const files = await response.json();
      const fileData = files.filter(file => file.type === "file").map(file => ({
        name: file.name,
        html_url: file.html_url,
        download_url: file.download_url,
      }));

      setRepoFiles(fileData);
    } catch (error) {
      console.error("Error fetching repo files:", error.message);
      alert("Failed to fetch files. Ensure the GitHub repo is public.");
    }
  };

  const toggleFileSelection = (url) => {
    setSelectedFiles(prev =>
      prev.includes(url)
        ? prev.filter(u => u !== url)
        : [...prev, url]
    );
  };

  const toggleDarkMode = () => {
    document.body.classList.toggle("dark-mode");
    setDarkMode(!darkMode);
  };

  return (
    
      <div className = "index-background">
        <div className="logo-group">
          <img src="/images/logo1.png" alt="Logo" className="logo" />
          <span className="logo-text">VeriCODE</span>
        </div>

        <div className="top-right-nav">
          <a href="/"><FontAwesomeIcon icon={faHome} color="black" title="Home"/></a>
          <button onClick={toggleDarkMode} className="nav-link">
              <FontAwesomeIcon icon={darkMode ? faSun : faMoon} title="DarkMode" className="toggle-icon" />
          </button>
          <a href="https://github.com/" target='_blank' rel='noopener noreferrer'> <FontAwesomeIcon icon={faGithub} color="black" title="GitHub"/></a>
          <a href='/config' title='Configure Code Review'>⚙️</a>
        </div>

        <main className="container">
          <section className="intro-section">
            <h2>Welcome to AI Code Reviewer</h2>
            <p>Analyze your code with AI-powered insights. Detect issues, optimize performance, and generate documentation effortlessly.</p>
          </section>

          <section className="upload-section">
            <h2>Get Started</h2>
            <div className="input-button-group">
              <input
                type="text"
                placeholder="Enter GitHub Repo URL"
                value={githubURL}
                onChange={(e) => setGithubURL(e.target.value)}
              />
              <button onClick={fetchRepoFiles}>📂 Show Files</button>
            </div>

            <input
              type="file"
              id="file-upload"
              multiple
              onChange={(e) => setFiles(e.target.files)}
            />
            <div style={{ margin: '10px 0' }}></div>

            <button onClick={handleAnalyze} disabled={loading}>
              {loading ? '🔄 Analyzing...' : 'Analyze'}
            </button>

            {repoFiles.length > 0 && (
              <div className="file-list-container">
                <h3>📁 Files in Repository</h3>
                <ul>
                  {repoFiles.map((file, index) => (
                    <li key={index}>
                      <input
                        type="checkbox"
                        value={file.download_url}
                        checked={selectedFiles.includes(file.download_url)}
                        onChange={() => toggleFileSelection(file.download_url)}
                        className="file-checkbox"
                      />
                      <a href={file.html_url} target="_blank" rel="noopener noreferrer">
                        {file.name}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </section>
        </main>
      </div>
  );
};

export default IndexPage;
