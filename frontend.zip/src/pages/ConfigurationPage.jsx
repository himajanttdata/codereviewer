import React, { useState, useEffect } from 'react';
import '../App.css';
 
const ConfigurationPage = () => {
  const [settings, setSettings] = useState({
    bugDetection: true,
    optimization: true,
    documentation: true,
    codingStandard: 'PEP8',
    darkMode: false,
  });
 
  useEffect(() => {
    const saved = localStorage.getItem('vericode-settings');
    if (saved) setSettings(JSON.parse(saved));
  }, []);
 
  const handleChange = (e) => {
    const { name, type, checked, value } = e.target;
    setSettings(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };
 
  const handleSave = () => {
    localStorage.setItem('vericode-settings', JSON.stringify(settings));
    alert("✅ Configuration saved successfully!");
  };
 
  return (
    <div className="container config-container">
      <h2 className="config-title">⚙️ Configuration Settings</h2>
 
      <div className="config-group">
        <label>
          <input
            type="checkbox"
            name="bugDetection"
            checked={settings.bugDetection}
            onChange={handleChange}
          />
          Enable Bug Detection
        </label>
 
        <label>
          <input
            type="checkbox"
            name="optimization"
            checked={settings.optimization}
            onChange={handleChange}
          />
          Enable Code Optimization
        </label>
 
        <label>
          <input
            type="checkbox"
            name="documentation"
            checked={settings.documentation}
            onChange={handleChange}
          />
          Generate Documentation
        </label>
 
        <label>
          Coding Standard:
          <select
            name="codingStandard"
            value={settings.codingStandard}
            onChange={handleChange}
          >
            <option value="PEP8">PEP8</option>
            <option value="Google">Google</option>
            <option value="Airbnb">Airbnb</option>
          </select>
        </label>
 
        <label>
          <input
            type="checkbox"
            name="darkMode"
            checked={settings.darkMode}
            onChange={handleChange}
          />
          Default Dark Mode
        </label>
      </div>
 
      <button className="input-button" onClick={handleSave}>💾 Save Settings</button>
    </div>
  );
};
 
export default ConfigurationPage;